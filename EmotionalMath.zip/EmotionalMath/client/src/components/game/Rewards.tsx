import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const badges = [
  { score: 50, image: "https://images.unsplash.com/photo-1548126466-4470dfd3a209" },
  { score: 100, image: "https://images.unsplash.com/photo-1571008840902-28bf8f9cd71a" },
  { score: 200, image: "https://images.unsplash.com/photo-1571008592377-e362723e8998" },
];

interface RewardsProps {
  score: number;
}

export default function Rewards({ score }: RewardsProps) {
  return (
    <div className="grid grid-cols-3 gap-4">
      {badges.map((badge) => (
        <motion.div
          key={badge.score}
          className={`relative ${score >= badge.score ? "opacity-100" : "opacity-50"}`}
          whileHover={{ scale: 1.05 }}
        >
          <img
            src={badge.image}
            alt={`${badge.score} points badge`}
            className="w-full rounded-lg"
          />
          <Badge
            className="absolute bottom-2 right-2"
            variant={score >= badge.score ? "default" : "secondary"}
          >
            {badge.score} pts
          </Badge>
        </motion.div>
      ))}
    </div>
  );
}
