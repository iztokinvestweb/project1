import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";

export default function Home() {
  const [name, setName] = useState("");
  const { toast } = useToast();
  
  const createPlayer = async () => {
    if (!name.trim()) {
      toast({ title: "Please enter your name", variant: "destructive" });
      return;
    }
    
    try {
      const res = await apiRequest("POST", "/api/players", { name });
      const player = await res.json();
      localStorage.setItem("playerId", player.id.toString());
      window.location.href = "/game";
    } catch (error) {
      toast({ title: "Failed to create player", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-400 to-purple-600 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-3xl text-center font-bold text-purple-600">
            Math Adventure!
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-lg font-medium">Enter Your Name</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="text-lg"
            />
          </div>
          <Button
            onClick={createPlayer}
            className="w-full text-lg h-12"
            size="lg"
          >
            Start Playing!
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
