import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

interface ProblemProps {
  problem: {
    num1: number;
    num2: number;
    operation: string;
    answer: number;
  };
  onAnswer: (answer: number) => void;
}

export default function Problem({ problem, onAnswer }: ProblemProps) {
  const [input, setInput] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAnswer = parseInt(input);
    if (!isNaN(numAnswer)) {
      onAnswer(numAnswer);
      setInput("");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center space-y-6"
    >
      <div className="text-4xl font-bold space-x-4">
        <span>{problem.num1}</span>
        <span>{problem.operation}</span>
        <span>{problem.num2}</span>
        <span>=</span>
        <span>?</span>
      </div>

      <form onSubmit={handleSubmit} className="flex gap-4 justify-center">
        <Input
          type="number"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="w-24 text-2xl text-center"
          autoFocus
        />
        <Button type="submit" size="lg">
          Check
        </Button>
      </form>
    </motion.div>
  );
}
