import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  currentLevel: integer("current_level").notNull().default(1),
  score: integer("score").notNull().default(0),
  settings: text("settings").notNull().default('{"maxNumber": 10, "operations": ["+"]}'),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  type: text("type").notNull(), // PERFECT_SCORE, LEVEL_UP, etc.
  earnedAt: text("earned_at").notNull(),
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  name: true,
});

export const settingsSchema = z.object({
  maxNumber: z.number().min(5).max(20),
  operations: z.array(z.enum(["+", "-"])),
});

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type GameSettings = z.infer<typeof settingsSchema>;
