import { motion } from "framer-motion";

interface CharacterProps {
  emotion: "neutral" | "happy" | "sad";
}

const characterImages = {
  neutral: "https://images.unsplash.com/photo-1631582053308-40f482e7ace5",
  happy: "https://images.unsplash.com/photo-1534481016308-0fca71578ae5",
  sad: "https://images.unsplash.com/photo-1630314021935-dc83d4dbc4da",
};

export default function Character({ emotion }: CharacterProps) {
  return (
    <motion.div
      className="w-32 h-32 mx-auto mb-8"
      animate={{
        scale: emotion === "neutral" ? 1 : 1.1,
        rotate: emotion === "happy" ? 5 : emotion === "sad" ? -5 : 0,
      }}
    >
      <img
        src={characterImages[emotion]}
        alt={`Character feeling ${emotion}`}
        className="w-full h-full object-cover rounded-full"
      />
    </motion.div>
  );
}
