import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/hooks/use-toast";
import type { GameSettings, Player } from "@shared/schema";

export default function Settings() {
  const { toast } = useToast();
  const playerId = localStorage.getItem("playerId");

  const { data: player, isLoading } = useQuery<Player>({
    queryKey: [`/api/players/${playerId}`],
    enabled: !!playerId,
  });

  const currentSettings: GameSettings = player
    ? JSON.parse(player.settings)
    : { maxNumber: 10, operations: ["+"] };

  const [settings, setSettings] = useState<GameSettings>(currentSettings);

  const updateSettings = useMutation({
    mutationFn: async (newSettings: GameSettings) => {
      await apiRequest("PATCH", `/api/players/${playerId}/settings`, newSettings);
      await queryClient.invalidateQueries({ queryKey: [`/api/players/${playerId}`] });
    },
    onSuccess: () => {
      toast({ title: "Settings saved!" });
    },
  });

  const toggleOperation = (op: "+" | "-") => {
    const ops = new Set(settings.operations);
    if (ops.has(op)) {
      if (ops.size > 1) ops.delete(op);
    } else {
      ops.add(op);
    }
    setSettings({ ...settings, operations: Array.from(ops) });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-400 to-purple-600 flex items-center justify-center">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (!player) {
    window.location.href = "/";
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-400 to-purple-600 p-4">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Game Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-lg font-medium">Maximum Number: {settings.maxNumber}</label>
            <Slider
              value={[settings.maxNumber]}
              onValueChange={([value]) =>
                setSettings({ ...settings, maxNumber: value })
              }
              min={5}
              max={20}
              step={1}
            />
          </div>

          <div className="space-y-4">
            <label className="text-lg font-medium">Operations</label>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span>Addition (+)</span>
                <Switch
                  checked={settings.operations.includes("+")}
                  onCheckedChange={() => toggleOperation("+")}
                />
              </div>
              <div className="flex items-center justify-between">
                <span>Subtraction (-)</span>
                <Switch
                  checked={settings.operations.includes("-")}
                  onCheckedChange={() => toggleOperation("-")}
                />
              </div>
            </div>
          </div>

          <Button
            className="w-full"
            onClick={() => updateSettings.mutate(settings)}
            disabled={updateSettings.isPending}
          >
            Save Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}