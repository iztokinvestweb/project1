import { players, achievements, type Player, type InsertPlayer, type Achievement } from "@shared/schema";

export interface IStorage {
  getPlayer(id: number): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayerScore(id: number, score: number): Promise<Player>;
  updatePlayerLevel(id: number, level: number): Promise<Player>;
  updatePlayerSettings(id: number, settings: string): Promise<Player>;
  addAchievement(playerId: number, type: string): Promise<Achievement>;
  getPlayerAchievements(playerId: number): Promise<Achievement[]>;
}

export class MemStorage implements IStorage {
  private players: Map<number, Player>;
  private achievements: Map<number, Achievement[]>;
  private currentId: number;
  private achievementId: number;

  constructor() {
    this.players = new Map();
    this.achievements = new Map();
    this.currentId = 1;
    this.achievementId = 1;
  }

  async getPlayer(id: number): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.currentId++;
    const player: Player = {
      id,
      ...insertPlayer,
      currentLevel: 1,
      score: 0,
      settings: '{"maxNumber": 10, "operations": ["+"]}',
    };
    this.players.set(id, player);
    return player;
  }

  async updatePlayerScore(id: number, score: number): Promise<Player> {
    const player = await this.getPlayer(id);
    if (!player) throw new Error("Player not found");
    const updated = { ...player, score };
    this.players.set(id, updated);
    return updated;
  }

  async updatePlayerLevel(id: number, level: number): Promise<Player> {
    const player = await this.getPlayer(id);
    if (!player) throw new Error("Player not found");
    const updated = { ...player, currentLevel: level };
    this.players.set(id, updated);
    return updated;
  }

  async updatePlayerSettings(id: number, settings: string): Promise<Player> {
    const player = await this.getPlayer(id);
    if (!player) throw new Error("Player not found");
    const updated = { ...player, settings };
    this.players.set(id, updated);
    return updated;
  }

  async addAchievement(playerId: number, type: string): Promise<Achievement> {
    const achievement: Achievement = {
      id: this.achievementId++,
      playerId,
      type,
      earnedAt: new Date().toISOString(),
    };
    const existing = this.achievements.get(playerId) || [];
    this.achievements.set(playerId, [...existing, achievement]);
    return achievement;
  }

  async getPlayerAchievements(playerId: number): Promise<Achievement[]> {
    return this.achievements.get(playerId) || [];
  }
}

export const storage = new MemStorage();
