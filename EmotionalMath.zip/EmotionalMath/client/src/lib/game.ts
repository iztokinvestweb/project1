import type { GameSettings } from "@shared/schema";

interface Problem {
  num1: number;
  num2: number;
  operation: string;
  answer: number;
}

export function generateProblem(level: number, settings?: GameSettings): Problem {
  const maxNum = settings?.maxNumber || 10;
  const operations = settings?.operations || ["+"];
  
  const operation = operations[Math.floor(Math.random() * operations.length)];
  let num1 = Math.floor(Math.random() * maxNum * level) + 1;
  let num2 = Math.floor(Math.random() * maxNum * level) + 1;
  
  // Ensure subtraction doesn't result in negative numbers
  if (operation === "-" && num1 < num2) {
    [num1, num2] = [num2, num1];
  }
  
  const answer = operation === "+" ? num1 + num2 : num1 - num2;
  
  return {
    num1,
    num2,
    operation,
    answer,
  };
}
