import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import Character from "@/components/game/Character";
import Problem from "@/components/game/Problem";
import Rewards from "@/components/game/Rewards";
import { generateProblem } from "@/lib/game";
import { playSound } from "@/lib/sounds";
import type { GameSettings, Player } from "@shared/schema";

export default function Game() {
  const playerId = localStorage.getItem("playerId");
  const [problem, setProblem] = useState(generateProblem(1));
  const [emotion, setEmotion] = useState<"neutral" | "happy" | "sad">("neutral");

  const { data: player, isLoading } = useQuery<Player>({
    queryKey: [`/api/players/${playerId}`],
    enabled: !!playerId,
  });

  const settings: GameSettings = player ? JSON.parse(player.settings) : {
    maxNumber: 10,
    operations: ["+"],
  };

  const updateScore = useMutation({
    mutationFn: async (score: number) => {
      await apiRequest("PATCH", `/api/players/${playerId}/score`, { score });
      await queryClient.invalidateQueries({ queryKey: [`/api/players/${playerId}`] });
    },
  });

  const checkAnswer = (answer: number) => {
    if (answer === problem.answer) {
      setEmotion("happy");
      playSound("correct");
      if (player) {
        updateScore.mutate(player.score + 10);
      }
      setTimeout(() => {
        setProblem(generateProblem(player?.currentLevel || 1, settings));
        setEmotion("neutral");
      }, 1000);
    } else {
      setEmotion("sad");
      playSound("wrong");
      setTimeout(() => setEmotion("neutral"), 1000);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-400 to-purple-600 flex items-center justify-center">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (!player) {
    window.location.href = "/";
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-400 to-purple-600 p-4">
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Level {player.currentLevel}</h1>
          <div className="text-xl text-white">Score: {player.score}</div>
        </div>

        <Card className="p-6">
          <Character emotion={emotion} />
          <Problem problem={problem} onAnswer={checkAnswer} />
        </Card>

        <Rewards score={player.score} />
      </div>
    </div>
  );
}