import { Howl } from "howler";

const sounds = {
  correct: new Howl({
    src: ["https://assets.mixkit.co/sfx/preview/mixkit-unlock-game-notification-253.mp3"],
  }),
  wrong: new Howl({
    src: ["https://assets.mixkit.co/sfx/preview/mixkit-wrong-answer-fail-notification-946.mp3"],
  }),
};

export function playSound(type: keyof typeof sounds) {
  sounds[type].play();
}
