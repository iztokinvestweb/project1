import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertPlayerSchema, settingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  app.post("/api/players", async (req, res) => {
    const result = insertPlayerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid player data" });
    }
    const player = await storage.createPlayer(result.data);
    res.json(player);
  });

  app.get("/api/players/:id", async (req, res) => {
    const player = await storage.getPlayer(Number(req.params.id));
    if (!player) return res.status(404).json({ error: "Player not found" });
    res.json(player);
  });

  app.patch("/api/players/:id/score", async (req, res) => {
    const { score } = req.body;
    if (typeof score !== "number") {
      return res.status(400).json({ error: "Invalid score" });
    }
    const player = await storage.updatePlayerScore(Number(req.params.id), score);
    res.json(player);
  });

  app.patch("/api/players/:id/level", async (req, res) => {
    const { level } = req.body;
    if (typeof level !== "number") {
      return res.status(400).json({ error: "Invalid level" });
    }
    const player = await storage.updatePlayerLevel(Number(req.params.id), level);
    res.json(player);
  });

  app.patch("/api/players/:id/settings", async (req, res) => {
    const result = settingsSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid settings" });
    }
    const player = await storage.updatePlayerSettings(
      Number(req.params.id),
      JSON.stringify(result.data)
    );
    res.json(player);
  });

  app.post("/api/players/:id/achievements", async (req, res) => {
    const { type } = req.body;
    if (typeof type !== "string") {
      return res.status(400).json({ error: "Invalid achievement type" });
    }
    const achievement = await storage.addAchievement(Number(req.params.id), type);
    res.json(achievement);
  });

  app.get("/api/players/:id/achievements", async (req, res) => {
    const achievements = await storage.getPlayerAchievements(Number(req.params.id));
    res.json(achievements);
  });

  return httpServer;
}
